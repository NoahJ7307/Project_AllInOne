import { Box } from '@mui/material'
import React from 'react'

const Home = () => {
    // 각 동 별 총 가입자 수 현황
    // 일주일 간 방문예약 수 현황
    // 각 동 별 총 방문 예약 수 현황
    // 일주일 간 독서실 예약자 수 현황 -> 더미로 구현
    // 각 동 별 총 독서실 예약 수 현황 -> 더미로 구현
    
    return (
        <Box sx={{ flex: 4, p: 2, height: '80vh' }}>
            
        </Box>
    )
}

export default Home