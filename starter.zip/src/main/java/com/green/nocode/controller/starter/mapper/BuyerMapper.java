package com.green.nocode.controller.starter.mapper;

import com.green.nocode.controller.starter.vo.BuyerVO;
import com.green.nocode.controller.starter.vo.UserVO;

import java.util.List;

public interface BuyerMapper {
    public List<BuyerVO> getAllBuyers();
    public int insertBuyer(BuyerVO  vo);
}
