package com.green.nocode.controller.starter.vo;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BuyerVO {
    private int bid ;
    private String  goods;
    private int price;
    private  float amount;
    private float total;
    private int uid;
}
