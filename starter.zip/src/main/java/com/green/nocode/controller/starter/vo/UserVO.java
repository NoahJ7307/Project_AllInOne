package com.green.nocode.controller.starter.vo;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserVO {
    private int id;
    private String name;
    private String  address;
    private String   phone;
    private int  age;
    private int  familyNumber;
}
