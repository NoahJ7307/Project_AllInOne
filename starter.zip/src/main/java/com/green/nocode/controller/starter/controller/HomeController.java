package com.green.nocode.controller.starter.controller;


import com.green.nocode.controller.starter.mapper.UserMapper;
import com.green.nocode.controller.starter.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class HomeController {

    @Autowired
    UserMapper mapper;

    @GetMapping
    public List<UserVO> home(){
        System.out.println("사랑");
        mapper.getAllUsers().forEach(i-> System.out.println(i));
        return mapper.getAllUsers();
    }
    @PostMapping
    public String userInsert(@RequestBody UserVO vo){
        System.out.println(vo);
        int cnt =mapper.insertUser(vo);
        return  cnt!=0?"성공":"실패";

    }
}
