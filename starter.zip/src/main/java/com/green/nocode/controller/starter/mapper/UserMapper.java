package com.green.nocode.controller.starter.mapper;

import com.green.nocode.controller.starter.vo.UserVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    public List<UserVO> getAllUsers();
    public int insertUser(UserVO vo);
}
