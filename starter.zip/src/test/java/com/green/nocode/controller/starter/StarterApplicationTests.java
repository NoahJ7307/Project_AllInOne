package com.green.nocode.controller.starter;

import com.green.nocode.controller.starter.mapper.BuyerMapper;
import com.green.nocode.controller.starter.mapper.UserMapper;
import com.green.nocode.controller.starter.vo.UserVO;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@MapperScan("com.green.nocode.controller.starter.mapper")
class StarterApplicationTests {
	@Autowired
	private UserMapper umapper;

	@Autowired
	private BuyerMapper bMapper;
	int[][] arr ={
			{5,4},
			{12,3},
			{40,7},
			{34,11},
			{77,2},
			{88,1},
			{45,5},
			{17,7},
			{56,2},
			{100,11}
	}; //나이와 가족수
	String[][] addressAndName={
			{"서울","홍길동"},
			{"부산","김개똥"},
			{"마산","최수종"},
			{"홍콩","하희라"},
			{"미국","이경규"},
			{"중국","손홍민"},
			{"인도네시아","이천수"},
			{"말레이지아","박지성"},
			{"마카오","박지성아빠"},
			{"남미","박지성엄마"}
	};
	@Test
	public void insertUser	(){
		for (int i = 0; i <arr.length ; i++) {
			UserVO a =new UserVO(0,"","","",arr[i][0],arr[i][1]);
			a.setAddress(addressAndName[i][0]);
			a.setName(addressAndName[i][1]);
			a.setPhone("010-1111-123"+i);
			umapper.insertUser(a);
		}
	}

	@Test
	public void getUserList(){
		umapper.getAllUsers().forEach(i-> System.out.println(i));
	}
	//문 1)  buy_TBL에 데이터를 랜덤하게 추가하세요
	//userid 가 1번일때 5개 데이터
	// 2번 일때 데이터는 7개 , 이런식으로 데이터가 갯수가 일정하지 않도록 추가
	//승균 재윤
}
